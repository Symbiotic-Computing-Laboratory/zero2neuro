# Mosquito Time-Series Experiment

This folder provides a complete setup for training neural networks on the `Mosquito_Data_Merged_with_Cov_Data_clean.xlsx` dataset using the Zero2Neuro framework.

## Data Structure & Pivoting
The raw dataset is in **long format** (one row per location per epiweek). The Zero2Neuro framework handles this natively using its tabular pivot feature! 

The `data.txt` file uses the following arguments to automatically transform the raw Excel file into a 3D time-series tensor `(32 locations, 30 epiweeks, 12 features)` directly in memory:
- `--tabular_pivot_by=Location.Name`
- `--tabular_time_col=Epiweek`
- `--tabular_missing_threshold=0.8`

## Network Architectures Available
1. **LSTM** (`network_lstm.txt`): Best for long-range temporal dependencies.
2. **GRU** (`network_gru.txt`): Lighter alternative to LSTM, trains faster.
3. **RNN** (`network_rnn.txt`): Vanilla RNN, good for quick baselines.
4. **CNN** (`network_cnn.txt`): 1D Convolution over time to detect local week-to-week spikes.
5. **FC** (`network_fc.txt`): Fully connected baseline (ignores time order entirely).

---

## How to Run
All commands must be executed from the **ZeroProject root directory** with the `NEURO_REPOSITORY_PATH` environment variable set.

### Option 1 — Run Everything (Recommended)
This batch file will automatically set the environment variable and run all 5 architectures sequentially:
```bat
zero2neuro\examples\mosquito\run.bat
```

### Option 2 — Validate a single network (dry run, no training)
```bat
set NEURO_REPOSITORY_PATH=%CD%
.venv\Scripts\python.exe zero2neuro\src\zero2neuro.py ^
    @zero2neuro/examples/mosquito/data.txt ^
    @zero2neuro/examples/mosquito/experiment.txt ^
    @zero2neuro/examples/mosquito/network_lstm.txt ^
    --dataset_directory zero2neuro/examples/mosquito ^
    -vvv --nogo
```

### Option 3 — Run with Normalization plugin (Keras layer)
Add `--normalize --normalize_axis=-1` to any command:
```bat
set NEURO_REPOSITORY_PATH=%CD%
.venv\Scripts\python.exe zero2neuro\src\zero2neuro.py ^
    @zero2neuro/examples/mosquito/data.txt ^
    @zero2neuro/examples/mosquito/experiment.txt ^
    @zero2neuro/examples/mosquito/network_lstm.txt ^
    --dataset_directory zero2neuro/examples/mosquito ^
    --normalize --normalize_axis=-1 -vvv
```

## Changing Inputs/Outputs
To change the climate features used as input or the mosquito species used as output, you simply need to edit `data.txt`. Make sure to update the `--data_inputs` and `--data_outputs` columns. Note: because the data is pivoted, input columns must be listed in the format `{epiweek}_{featurename}` (e.g., `19_Precip.RS.`).
