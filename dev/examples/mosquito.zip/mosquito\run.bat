@echo off
REM ─────────────────────────────────────────────────────────────
REM  run.bat  —  Mosquito Experiment Runner (Windows)
REM  Run from the ZeroProject root directory:
REM      zero2neuro\examples\mosquito\run.bat
REM ─────────────────────────────────────────────────────────────

SET VENV=.venv\Scripts\python.exe
SET Z2N=zero2neuro\src\zero2neuro.py
SET EX=zero2neuro\examples\mosquito

REM Required: set the environment variable for zero2neuro
SET NEURO_REPOSITORY_PATH=%CD%

echo.
echo =====================================================
echo  STEP 1: LSTM  (best for long-range weekly patterns)
echo =====================================================
%VENV% %Z2N% @%EX%\data.txt @%EX%\experiment.txt @%EX%\network_lstm.txt @%EX%\report.txt --dataset_directory %EX% -vvv

echo.
echo =====================================================
echo  STEP 2: GRU   (lighter LSTM alternative)
echo =====================================================
%VENV% %Z2N% @%EX%\data.txt @%EX%\experiment.txt @%EX%\network_gru.txt @%EX%\report.txt --dataset_directory %EX% -vvv

echo.
echo =====================================================
echo  STEP 3: Vanilla RNN  (simplest recurrent model)
echo =====================================================
%VENV% %Z2N% @%EX%\data.txt @%EX%\experiment.txt @%EX%\network_rnn.txt @%EX%\report.txt --dataset_directory %EX% -vvv

echo.
echo =====================================================
echo  STEP 4: 1D CNN  (detects local epiweek patterns)
echo =====================================================
%VENV% %Z2N% @%EX%\data.txt @%EX%\experiment.txt @%EX%\network_cnn.txt @%EX%\report.txt --dataset_directory %EX% -vvv

echo.
echo =====================================================
echo  STEP 5: Fully Connected  (baseline, no time-awareness)
echo =====================================================
%VENV% %Z2N% @%EX%\data.txt @%EX%\experiment.txt @%EX%\network_fc.txt @%EX%\report.txt --dataset_directory %EX% -vvv

echo.
echo =====================================================
echo  All experiments complete.  Results in: %EX%\results\
echo =====================================================
pause
